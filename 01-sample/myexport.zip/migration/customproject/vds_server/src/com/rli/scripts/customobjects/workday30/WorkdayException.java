package com.rli.scripts.customobjects.workday30;

public class WorkdayException extends Exception {

	public WorkdayException(String msg) {
		super(msg);
	}
}
